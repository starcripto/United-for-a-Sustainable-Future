import React from 'react';
import { Globe2, Users, Lightbulb, HandHeart, MessageSquare } from 'lucide-react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Features from './components/Features';
import Projects from './components/Projects';
import CommunitySection from './components/CommunitySection';

function App() {
  const features = [
    {
      icon: <HandHeart className="w-8 h-8 text-green-600" />,
      title: "Common Investment Fund",
      description: "Donate and support projects that combat climate change and help in natural disasters."
    },
    {
      icon: <Lightbulb className="w-8 h-8 text-yellow-500" />,
      title: "Projects & Initiatives",
      description: "Discover and support innovative projects that are making a difference in communities."
    },
    {
      icon: <Globe2 className="w-8 h-8 text-blue-500" />,
      title: "Educational Resources",
      description: "Access vital information about climate change and disaster preparedness."
    },
    {
      icon: <Users className="w-8 h-8 text-purple-500" />,
      title: "Active Community",
      description: "Join a global network of people committed to positive change."
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <Hero />
      <Features features={features} />
      <Projects />
      <CommunitySection />
    </div>
  );
}

export default App;