import React from 'react';

const Hero = () => {
  return (
    <div className="relative bg-green-600">
      <div className="absolute inset-0">
        <img
          className="w-full h-full object-cover"
          src="https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?auto=format&fit=crop&w=1920"
          alt="Nature"
        />
        <div className="absolute inset-0 bg-green-600 mix-blend-multiply"></div>
      </div>
      <div className="relative max-w-7xl mx-auto py-24 px-4 sm:py-32 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl">
          United for a Sustainable Future
        </h1>
        <p className="mt-6 max-w-3xl text-xl text-gray-100">
          Connecting people, resources, and solutions to combat climate change
          and support communities affected by natural disasters.
        </p>
        <div className="mt-10 flex space-x-4">
          <button className="bg-white text-green-600 px-8 py-3 rounded-md font-medium hover:bg-gray-50">
            Get Started
          </button>
          <button className="border-2 border-white text-white px-8 py-3 rounded-md font-medium hover:bg-white hover:text-green-600">
            Learn More
          </button>
        </div>
      </div>
    </div>
  );
};

export default Hero;